export interface customerModel {
  appointmentDate: string;
  appointmentID: number;
  dateOfBirth: string;
  firstName: string;
  lastName: string;
}
